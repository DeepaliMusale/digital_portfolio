self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b7c7e556024ea114fd4e21bcfa544aab",
    "url": "https://deepalimusale.github.io/digital_portfolio/index.html"
  },
  {
    "revision": "821697ec351c63194524",
    "url": "https://deepalimusale.github.io/digital_portfolio/static/css/main.5facb584.chunk.css"
  },
  {
    "revision": "7be0536ccae55efe2473",
    "url": "https://deepalimusale.github.io/digital_portfolio/static/js/2.2facac2b.chunk.js"
  },
  {
    "revision": "63a84f5c0b19c96be47a74b765284fbf",
    "url": "https://deepalimusale.github.io/digital_portfolio/static/js/2.2facac2b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "821697ec351c63194524",
    "url": "https://deepalimusale.github.io/digital_portfolio/static/js/main.58fd721b.chunk.js"
  },
  {
    "revision": "74fafb9f4eb9689d3cf6",
    "url": "https://deepalimusale.github.io/digital_portfolio/static/js/runtime-main.cf74cc53.js"
  }
]);